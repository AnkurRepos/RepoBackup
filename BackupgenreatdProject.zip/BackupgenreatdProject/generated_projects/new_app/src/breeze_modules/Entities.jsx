
const entities = {}
const entityDetails = {
  "047aec68_9c53_4410_86fa_97267d1ff143": {
    "exportedAs": "Main",
    "from": "/src/components/Main.jsx",
    "default": true
  },
  "6f417071_580c_4721_9d91_b8b8e64865b8": {
    "exportedAs": "App",
    "from": "/src/App.jsx",
    "default": true
  },
  "PROJECT_ROUTER": {
    "exportedAs": "router",
    "from": "/src/Routing.jsx",
    "default": true
  },
  "THEME_CSS": {
    "exportedAs": "ThemeContext",
    "from": "/src/styles/ThemeContext.css",
    "default": false
  },
  "THEME_HOOK": {
    "exportedAs": "useThemeContext",
    "from": "/src/context/ThemeContext.jsx",
    "default": false
  },
  "THEME_PROVIDER": {
    "exportedAs": "ThemeProvider",
    "from": "/src/context/ThemeContext.jsx",
    "default": false
  },
  "STYLES_MASTER": {
    "exportedAs": "stylesMaster",
    "from": "/src/stylesMaster.jsx",
    "default": false
  }
}



export async function loadEntity(id) {
  const { from, default: isDefault } = entityDetails[id];
  if (!entities[id]) {
    try {
      const module = await import(from);
      const entity = isDefault
        ? module.default
        : module[entityDetails[id]["exportedAs"]];
      entities[id] = entity;
    } catch (error) {
      console.error(`Failed to load ${from}:`, error);
    }
  }
  return entities[id];
}

