import { axiosInstance, duplicateInstance } from "../interceptors";

export const moduleInstance = duplicateInstance(axiosInstance);
moduleInstance.defaults.baseURL = import.meta.env.VITE_BIG_SCHEMA_EXAMPLE_API;
