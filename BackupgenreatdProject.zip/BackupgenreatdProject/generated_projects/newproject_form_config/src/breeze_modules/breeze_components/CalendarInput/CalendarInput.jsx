import { useState } from "react";
import PropTypes from "prop-types";

export const CalendarInput = ({
  // Functional Props
  disabled = false,
  id = "calendar-input",
  name = "calendarInput",
  readOnly = false,
  required = false,

  // Styling Props
  className = "calendar-input",
  style = {
    border: "1px solid #ccc",
    padding: "8px",
    borderRadius: "4px",
    width: "200px",
  },
  wrapperClassName = "calendar-wrapper",

  // Label Props
  labelText = "Select Date:",
  labelPosition = "left",
  labelVisibility = true,
  labelClassName = "calendar-label mt-2",
  requiredIndicator = false,

  // Calendar Props
  format = "yyyy-MM-dd",
  maxDate = null,
  minDate = null,
  onChange = () => {},
  placeholder = "Select a date",
  value = null,
}) => {
  const [internalValue, setInternalValue] = useState(value);

  const formatDate = (date) => {
    if (!date) return "";
    const d = new Date(date);
    const pad = (n) => String(n).padStart(2, "0");

    switch (format) {
      case "MM/dd/yyyy":
        return `${pad(d.getMonth() + 1)}/${pad(
          d.getDate()
        )}/${d.getFullYear()}`;
      case "dd/MM/yyyy":
        return `${pad(d.getDate())}/${pad(
          d.getMonth() + 1
        )}/${d.getFullYear()}`;
      case "yyyy-MM-dd":
      default:
        return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(
          d.getDate()
        )}`;
    }
  };

  const handleChange = (e) => {
    const date = e.target.value ? new Date(e.target.value) : null;
    setInternalValue(date);
    onChange(date);
  };

  const renderLabel = () =>
    labelVisibility && (
      <label
        htmlFor={id}
        className={labelClassName}
        style={{ marginBottom: "4px" }}
      >
        {labelText}{" "}
        {requiredIndicator && <span style={{ color: "red" }}>*</span>}
      </label>
    );

  return (
    <div
      className={wrapperClassName}
      style={{
        display: "flex",
        flexDirection:
          labelPosition === "left" || labelPosition === "right"
            ? "row"
            : "column",
        alignItems: "flex-start",
        gap: "8px",
      }}
    >
      {(labelPosition === "top" || labelPosition === "left") && renderLabel()}
      <input
        type="date"
        id={id}
        name={name}
        disabled={disabled}
        readOnly={readOnly}
        required={required}
        className={className}
        style={style}
        max={maxDate ? formatDate(maxDate) : undefined}
        min={minDate ? formatDate(minDate) : undefined}
        placeholder={placeholder}
        value={internalValue ? formatDate(internalValue) : ""}
        onChange={handleChange}
      />
      {(labelPosition === "bottom" || labelPosition === "right") &&
        renderLabel()}
    </div>
  );
};

CalendarInput.propTypes = {
  disabled: PropTypes.bool,
  id: PropTypes.string,
  name: PropTypes.string,
  readOnly: PropTypes.bool,
  required: PropTypes.bool,
  className: PropTypes.string,
  style: PropTypes.object,
  wrapperClassName: PropTypes.string,
  labelText: PropTypes.string,
  labelPosition: PropTypes.oneOf(["top", "bottom", "left", "right"]),
  labelVisibility: PropTypes.bool,
  labelClassName: PropTypes.string,
  requiredIndicator: PropTypes.bool,
  format: PropTypes.oneOf(["MM/dd/yyyy", "dd/MM/yyyy", "yyyy-MM-dd"]),
  maxDate: PropTypes.instanceOf(Date),
  minDate: PropTypes.instanceOf(Date),
  onChange: PropTypes.func,
  placeholder: PropTypes.string,
  value: PropTypes.instanceOf(Date),
};
