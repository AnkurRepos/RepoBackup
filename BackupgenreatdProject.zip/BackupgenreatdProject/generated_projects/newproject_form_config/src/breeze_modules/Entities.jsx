
const entities = {}
const entityDetails = {
  "PROJECT_ROUTER": {
    "exportedAs": "router",
    "from": "/src/Routing.jsx",
    "default": true
  },
  "THEME_CSS": {
    "exportedAs": "ThemeContext",
    "from": "/src/styles/ThemeContext.css",
    "default": false
  },
  "THEME_HOOK": {
    "exportedAs": "useThemeContext",
    "from": "/src/context/ThemeContext.jsx",
    "default": false
  },
  "THEME_PROVIDER": {
    "exportedAs": "ThemeProvider",
    "from": "/src/context/ThemeContext.jsx",
    "default": false
  },
  "ae0bfa52_c799_471f_9fec_9dc8c68541fc": {
    "exportedAs": "App",
    "from": "/src/App.jsx",
    "default": true
  },
  "c033cb21_3cc0_421b_8871_e02878ab75ca": {
    "exportedAs": "getProfiles",
    "from": "/src/services/Big Schema Example API/default.jsx",
    "default": false
  },
  "f3d6be82_f14f_4649_a7ca_588da55581af": {
    "exportedAs": "Dfh",
    "from": "/src/components/dfh.jsx",
    "default": true
  }
}



export async function loadEntity(id) {
  const { from, default: isDefault } = entityDetails[id];
  if (!entities[id]) {
    try {
      const module = await import(from);
      const entity = isDefault
        ? module.default
        : module[entityDetails[id]["exportedAs"]];
      entities[id] = entity;
    } catch (error) {
      console.error(`Failed to load ${from}:`, error);
    }
  }
  return entities[id];
}

