
const entities = {}
const entityDetails = {
  "036bc8dd_72ce_424e_b479_7e2468816346": {
    "exportedAs": "Main",
    "from": "/src/components/Main.jsx",
    "default": true
  },
  "26000bf0_9752_4b5c_8035_72e2267765a4": {
    "exportedAs": "createApiAuthRegister",
    "from": "/src/services/Auth & User Management API/default.jsx",
    "default": false
  },
  "354b9a5e_ab0f_4e92_8edc_eca4db3317ca": {
    "exportedAs": "getApiStats",
    "from": "/src/services/Auth & User Management API/default.jsx",
    "default": false
  },
  "402dec44_f6eb_4375_8655_d9f489f78a9a": {
    "exportedAs": "bearerAuthLogin",
    "from": "/src/services/Auth & User Management API/authApis.jsx",
    "default": false
  },
  "4140a41f_48b3_4cf8_b2a7_cd50501b80e2": {
    "exportedAs": "deleteApiUsersByEmail",
    "from": "/src/services/Auth & User Management API/default.jsx",
    "default": false
  },
  "66db7b76_503c_4e37_8d25_8f19bb6811d3": {
    "exportedAs": "getApiProfile",
    "from": "/src/services/Auth & User Management API/default.jsx",
    "default": false
  },
  "9581391f_a849_4eb6_a3e0_2bd90a8f8632": {
    "exportedAs": "updateApiUsersByEmail",
    "from": "/src/services/Auth & User Management API/default.jsx",
    "default": false
  },
  "9f48bc2b_2a15_48cb_b33c_d2da00d6f08b": {
    "exportedAs": "getApiUsersDetails",
    "from": "/src/services/Auth & User Management API/default.jsx",
    "default": false
  },
  "PROJECT_ROUTER": {
    "exportedAs": "router",
    "from": "/src/Routing.jsx",
    "default": true
  },
  "THEME_CSS": {
    "exportedAs": "ThemeContext",
    "from": "/src/styles/ThemeContext.css",
    "default": false
  },
  "THEME_HOOK": {
    "exportedAs": "useThemeContext",
    "from": "/src/context/ThemeContext.jsx",
    "default": false
  },
  "THEME_PROVIDER": {
    "exportedAs": "ThemeProvider",
    "from": "/src/context/ThemeContext.jsx",
    "default": false
  },
  "a8830374_3639_498d_8d40_d5ad6e2b2fac": {
    "exportedAs": "App",
    "from": "/src/App.jsx",
    "default": true
  },
  "c1a7ba12_6a7d_4667_a9c1_693856f13229": {
    "exportedAs": "clearAuthSessionAuthUserManagementAPI",
    "from": "/src/services/Auth & User Management API/authApis.jsx",
    "default": false
  },
  "dad69ac3_efef_4c12_8c9a_5777b3f9f83f": {
    "exportedAs": "createApiAuthLogin",
    "from": "/src/services/Auth & User Management API/default.jsx",
    "default": false
  },
  "e4a333f2_f54e_4fb2_aa32_e46fb7c28ef2": {
    "exportedAs": "getApiDashboard",
    "from": "/src/services/Auth & User Management API/default.jsx",
    "default": false
  },
  "f29ddd37_ca20_4f3f_891d_40aca04facb4": {
    "exportedAs": "getApiUsersSummary",
    "from": "/src/services/Auth & User Management API/default.jsx",
    "default": false
  }
}



export async function loadEntity(id) {
  const { from, default: isDefault } = entityDetails[id];
  if (!entities[id]) {
    try {
      const module = await import(from);
      const entity = isDefault
        ? module.default
        : module[entityDetails[id]["exportedAs"]];
      entities[id] = entity;
    } catch (error) {
      console.error(`Failed to load ${from}:`, error);
    }
  }
  return entities[id];
}

