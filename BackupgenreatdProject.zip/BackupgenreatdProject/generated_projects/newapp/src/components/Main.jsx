import { React } from "react";
const Main = ({ prop1 }) => {
  return <div>Hello world</div>;
};
export default Main;
