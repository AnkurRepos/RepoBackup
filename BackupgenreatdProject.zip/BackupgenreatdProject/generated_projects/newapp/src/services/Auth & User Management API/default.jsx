import axios from "axios";
import { duplicateInstance } from "../interceptors";
import { moduleInstance } from "./interceptors";
import {
  requestAuthInterceptorBearerAuthLogin,
  responseAuthInterceptorBearerAuthLogin,
} from "./interceptors";

export const createApiAuthRegister = async (RegisterRequest) => {
  const localInstance = duplicateInstance(moduleInstance);
  let url = `${import.meta.env.VITE_AUTH___USER_MANAGEMENT_API}api/auth/register`;

  const api = {
    method: "post",
    url: url,
    headers: { "content-type": "application/json" },
    data: { ...RegisterRequest },
  };

  let resp = await localInstance.request(api);

  return resp.data;
};

export const createApiAuthLogin = async (LoginRequest) => {
  const localInstance = duplicateInstance(moduleInstance);
  let url = `${import.meta.env.VITE_AUTH___USER_MANAGEMENT_API}api/auth/login`;

  const api = {
    method: "post",
    url: url,
    headers: { "content-type": "application/json" },
    data: { ...LoginRequest },
  };

  let resp = await localInstance.request(api);

  return resp.data;
};

export const getApiProfile = async () => {
  const localInstance = duplicateInstance(moduleInstance);
  let url = `${import.meta.env.VITE_AUTH___USER_MANAGEMENT_API}api/profile`;

  const api = {
    method: "get",
    url: url,
  };

  localInstance.interceptors.request.use(requestAuthInterceptorBearerAuthLogin);
  localInstance.interceptors.response.use(
    responseAuthInterceptorBearerAuthLogin,
  );

  let resp = await localInstance.request(api);

  return resp.data;
};

export const getApiStats = async () => {
  const localInstance = duplicateInstance(moduleInstance);
  let url = `${import.meta.env.VITE_AUTH___USER_MANAGEMENT_API}api/stats`;

  const api = {
    method: "get",
    url: url,
  };

  localInstance.interceptors.request.use(requestAuthInterceptorBearerAuthLogin);
  localInstance.interceptors.response.use(
    responseAuthInterceptorBearerAuthLogin,
  );

  let resp = await localInstance.request(api);

  return resp.data;
};

export const getApiDashboard = async () => {
  const localInstance = duplicateInstance(moduleInstance);
  let url = `${import.meta.env.VITE_AUTH___USER_MANAGEMENT_API}api/dashboard`;

  const api = {
    method: "get",
    url: url,
  };

  localInstance.interceptors.request.use(requestAuthInterceptorBearerAuthLogin);
  localInstance.interceptors.response.use(
    responseAuthInterceptorBearerAuthLogin,
  );

  let resp = await localInstance.request(api);

  return resp.data;
};

export const getApiUsersSummary = async () => {
  const localInstance = duplicateInstance(moduleInstance);
  let url = `${import.meta.env.VITE_AUTH___USER_MANAGEMENT_API}api/users/summary`;

  const api = {
    method: "get",
    url: url,
  };

  localInstance.interceptors.request.use(requestAuthInterceptorBearerAuthLogin);
  localInstance.interceptors.response.use(
    responseAuthInterceptorBearerAuthLogin,
  );

  let resp = await localInstance.request(api);

  return resp.data;
};

export const getApiUsersDetails = async () => {
  const localInstance = duplicateInstance(moduleInstance);
  let url = `${import.meta.env.VITE_AUTH___USER_MANAGEMENT_API}api/users/details`;

  const api = {
    method: "get",
    url: url,
  };

  localInstance.interceptors.request.use(requestAuthInterceptorBearerAuthLogin);
  localInstance.interceptors.response.use(
    responseAuthInterceptorBearerAuthLogin,
  );

  let resp = await localInstance.request(api);

  return resp.data;
};

export const updateApiUsersByEmail = async (UpdateUser, email) => {
  const localInstance = duplicateInstance(moduleInstance);
  let url = `${import.meta.env.VITE_AUTH___USER_MANAGEMENT_API}api/users/${email}`;

  const api = {
    method: "put",
    url: url,
    headers: { "content-type": "application/json" },
    data: { ...UpdateUser },
  };

  localInstance.interceptors.request.use(requestAuthInterceptorBearerAuthLogin);
  localInstance.interceptors.response.use(
    responseAuthInterceptorBearerAuthLogin,
  );

  let resp = await localInstance.request(api);

  return resp.data;
};

export const deleteApiUsersByEmail = async (email) => {
  const localInstance = duplicateInstance(moduleInstance);
  let url = `${import.meta.env.VITE_AUTH___USER_MANAGEMENT_API}api/users/${email}`;

  const api = {
    method: "delete",
    url: url,
  };

  localInstance.interceptors.request.use(requestAuthInterceptorBearerAuthLogin);
  localInstance.interceptors.response.use(
    responseAuthInterceptorBearerAuthLogin,
  );

  let resp = await localInstance.request(api);

  return resp.data;
};
