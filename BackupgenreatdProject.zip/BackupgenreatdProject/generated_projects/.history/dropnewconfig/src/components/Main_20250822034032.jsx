import { React } from "react";
import { useState } from "react";
import router from "/src/Routing.jsx";
import { getProfiles } from "/src/services/Big Schema Example API/default.jsx";
const Main = ({ prop1 }) => {
  const sd = "fw";
  const handleSubmit = () => {};
  const a = 10;
  const [rer, setRer] = useState({
    line1: prop1,
    line2: AnkPS,
    city: a,
    state: a,
    zip: a,
    country: router,
    coordinates: FormData,
  });
  const k = rer.city;
  const fe = rer.state;
  const b = 11;
  const m = rer.city;
  const sub = async () => {
    const res = await getProfiles();
  };
  const temp = async () => {
    await getProfiles();
  };
  return (
    <div id={rer.city}>
      <form>
        <div id={"Main"}>
          Main
          <div>
            <label>text</label>
            <input type={"text"} value={"formData.contact.email"} />
          </div>
          <button type={"submit"}>Submit</button>
        </div>
      </form>
      <form>
        <div id={"Main"}>
          Main
          <div>
            <label>text</label>
            <input type={text} value={formData.address.city} />
          </div>
          <button type={"submit"}>Submit</button>
        </div>
      </form>
    </div>
  );

  const [FormData, setFormdata] = useState();
  const [AnkPS, setAnkps] = useState();
};
export default Main;
