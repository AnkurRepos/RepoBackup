import { React } from "react";
import { useState } from "react";
import { getProfiles } from "/src/services/Big Schema Example API/default.jsx";
const Createcontactinfo = () => {
  const [FormData, setFormdata] = useState({
    email: "",
    phone: "",
    address: "",
  });
  const [error, setError] = useState(null);
  const handleFormChange = (e) => {
    setFormdata((prev) => {
      return {
        ...prev,
        [e.target.name]:
          e.target.type === "checkbox" ? e.target.checked : e.target.value,
      };
    });
  };
  const handleFormSubmit = async (e) => {
    try {
      e.preventDefault();
      const response = await getProfiles(FormData);
      setError(null);
    } catch (err) {
      setError("Something went wrong. Please try again");
    } finally {
    }
  };
  return (
    <div>
      <form
        onSubmit={handleFormSubmit}
        style={{
          maxWidth: "400px",
          margin: "40px auto",
          padding: "20px",
          backgroundColor: "#f9f9f9",
          border: "1px solid #ddd",
          borderRadius: "8px",
          boxShadow: "0 2px 8px rgba(0, 0, 0, 0.1)",
        }}
      >
        {error && (
          <div
            className={"d-flex mb-1 justify-content-center"}
            style={{ color: "red", fontSize: "14px" }}
          >
            {error}
          </div>
        )}
        <label
          htmlFor={"email"}
          style={{
            display: "block",
            marginBottom: "8px",
            fontWeight: "600",
            color: "#333",
            fontSize: "14px",
          }}
        >
          Email :
        </label>
        <input
          id={"email"}
          name={"email"}
          required={false}
          type={"text"}
          value={FormData.email}
          onChange={handleFormChange}
          style={{
            width: "100%",
            padding: "10px 12px",
            marginBottom: "16px",
            border: "1px solid #ccc",
            borderRadius: "6px",
            fontSize: "14px",
            boxSizing: "border-box",
          }}
        />
        <br />
        <label
          htmlFor={"phone"}
          style={{
            display: "block",
            marginBottom: "8px",
            fontWeight: "600",
            color: "#333",
            fontSize: "14px",
          }}
        >
          Phone :
        </label>
        <input
          id={"phone"}
          name={"phone"}
          required={false}
          type={"text"}
          value={FormData.phone}
          onChange={handleFormChange}
          style={{
            width: "100%",
            padding: "10px 12px",
            marginBottom: "16px",
            border: "1px solid #ccc",
            borderRadius: "6px",
            fontSize: "14px",
            boxSizing: "border-box",
          }}
        />
        <br />
        <label
          htmlFor={"address"}
          style={{
            display: "block",
            marginBottom: "8px",
            fontWeight: "600",
            color: "#333",
            fontSize: "14px",
          }}
        >
          Address :
        </label>
        <input
          id={"address"}
          name={"address"}
          required={false}
          type={"text"}
          value={FormData.address}
          onChange={handleFormChange}
          style={{
            width: "100%",
            padding: "10px 12px",
            marginBottom: "16px",
            border: "1px solid #ccc",
            borderRadius: "6px",
            fontSize: "14px",
            boxSizing: "border-box",
          }}
        />
        <br />
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            gap: "16px",
            marginTop: "20px",
          }}
        >
          <input
            type={"submit"}
            value={"Submit"}
            style={{
              padding: "10px 20px",
              backgroundColor: "#4caf50",
              color: "white",
              border: "none",
              borderRadius: "6px",
              fontSize: "16px",
              cursor: "pointer",
            }}
          />
        </div>
        <br />
      </form>
    </div>
  );
};
export default Createcontactinfo;
