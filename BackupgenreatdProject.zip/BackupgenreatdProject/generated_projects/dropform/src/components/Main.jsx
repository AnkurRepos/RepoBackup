import { React } from "react";
const Main = ({ prop1 }) => {
  return <div id={"d"} />;
};
export default Main;
