
const entities = {}
const entityDetails = {
  "008c73fb_7b58_43b1_91b1_ea59435261be": {
    "exportedAs": "getProfiles",
    "from": "/src/services/Big Schema Example API/default.jsx",
    "default": false
  },
  "16c10f7f_c150_4ef7_b53a_c99a232410c8": {
    "exportedAs": "App",
    "from": "/src/App.jsx",
    "default": true
  },
  "3c563cba_91c6_4f3d_a7a8_a8c37a6455b1": {
    "exportedAs": "Createcontactinfo",
    "from": "/src/components/CreateContactInfo.jsx",
    "default": true
  },
  "6b292e23_361d_47c3_88d8_e660efdb1545": {
    "exportedAs": "Main",
    "from": "/src/components/Main.jsx",
    "default": true
  },
  "PROJECT_ROUTER": {
    "exportedAs": "router",
    "from": "/src/Routing.jsx",
    "default": true
  },
  "STYLES_MASTER": {
    "exportedAs": "stylesMaster",
    "from": "/src/stylesMaster.jsx",
    "default": false
  },
  "THEME_CSS": {
    "exportedAs": "ThemeContext",
    "from": "/src/styles/ThemeContext.css",
    "default": false
  },
  "THEME_HOOK": {
    "exportedAs": "useThemeContext",
    "from": "/src/context/ThemeContext.jsx",
    "default": false
  },
  "THEME_PROVIDER": {
    "exportedAs": "ThemeProvider",
    "from": "/src/context/ThemeContext.jsx",
    "default": false
  }
}



export async function loadEntity(id) {
  const { from, default: isDefault } = entityDetails[id];
  if (!entities[id]) {
    try {
      const module = await import(from);
      const entity = isDefault
        ? module.default
        : module[entityDetails[id]["exportedAs"]];
      entities[id] = entity;
    } catch (error) {
      console.error(`Failed to load ${from}:`, error);
    }
  }
  return entities[id];
}

