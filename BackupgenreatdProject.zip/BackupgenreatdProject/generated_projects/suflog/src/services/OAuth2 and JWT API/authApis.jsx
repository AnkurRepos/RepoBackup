import axios from "axios";
import { duplicateInstance } from "../interceptors";
import { moduleInstance } from "./interceptors";

export const clearAuthSessionOAuth2AndJWTAPI = async () => {
  localStorage.removeItem("5508f91e_a56b_4886_97f1_7b0434995dab_accessToken");
  localStorage.removeItem("5508f91e_a56b_4886_97f1_7b0434995dab_refreshToken");
};

export const bearerAuthLogin = async (defaultRegisterPost) => {
  const localInstance = duplicateInstance(moduleInstance);
  let url = `${import.meta.env.VITE_OAUTH2_AND_JWT_API}auth/login`;

  const api = {
    method: "post",
    url: url,
    headers: { "content-type": "application/json" },
    data: { ...defaultRegisterPost },
  };

  let resp = await localInstance.request(api);
  localStorage.setItem(
    "5508f91e_a56b_4886_97f1_7b0434995dab_accessToken",
    `${resp.data.accessToken}`,
  );
  localStorage.setItem(
    "5508f91e_a56b_4886_97f1_7b0434995dab_refreshToken",
    `${resp.data.refreshToken}`,
  );

  return resp.data;
};

export const googleAuthLogin = async () => {
  return new Promise((resolve, reject) => {
    const scope = encodeURIComponent("openid profile email");
    const authUrl = `https://accounts.google.com/o/oauth2/auth?client_id=${import.meta.env.VITE_CLIENT_ID_OAUTH2_AND_JWT_API}&redirect_uri=&response_type=code&scope=${scope}`;

    const width = 500;
    const height = 600;
    const left = window.screenX + (window.innerWidth - width) / 2;
    const top = window.screenY + (window.innerHeight - height) / 2;

    const popup = window.open(
      authUrl,
      "GoogleAuth",
      `width=${width},height=${height},top=${top},left=${left}`,
    );

    if (!popup) {
      return reject(
        new Error("Popup blocked. Please allow popups and try again."),
      );
    }

    const polling = setInterval(async () => {
      try {
        if (popup.location.href.startsWith("")) {
          const urlParams = new URLSearchParams(popup.location.search);
          const code = urlParams.get("code");

          if (code) {
            clearInterval(polling);
            popup.close();

            try {
              // Handling according to flow using Axios
              const response = resolve(response.data);
            } catch (err) {
              reject(err);
            }
          }
        }
      } catch (error) {
        // Ignoring cross-origin errors while polling
      }
    }, 500);
  });
};
