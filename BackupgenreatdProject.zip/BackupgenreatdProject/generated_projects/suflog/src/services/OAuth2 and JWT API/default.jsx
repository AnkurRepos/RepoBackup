import axios from "axios";
import { duplicateInstance } from "../interceptors";
import { moduleInstance } from "./interceptors";
import {
  requestAuthInterceptorBearerAuthLogin,
  responseAuthInterceptorBearerAuthLogin,
} from "./interceptors";

export const exchangeAuthCodeForToken = async (defaultTokenPost) => {
  const localInstance = duplicateInstance(moduleInstance);
  let url = `${import.meta.env.VITE_OAUTH2_AND_JWT_API}auth/token`;

  const api = {
    method: "post",
    url: url,
    headers: { "content-type": "application/json" },
    data: { ...defaultTokenPost },
  };

  let resp = await localInstance.request(api);

  return resp.data;
};

export const registerUser = async (defaultRegisterPost) => {
  const localInstance = duplicateInstance(moduleInstance);
  let url = `${import.meta.env.VITE_OAUTH2_AND_JWT_API}auth/register`;

  const api = {
    method: "post",
    url: url,
    headers: { "content-type": "application/json" },
    data: { ...defaultRegisterPost },
  };

  let resp = await localInstance.request(api);

  return resp.data;
};

export const loginUser = async (defaultRegisterPost) => {
  const localInstance = duplicateInstance(moduleInstance);
  let url = `${import.meta.env.VITE_OAUTH2_AND_JWT_API}auth/login`;

  const api = {
    method: "post",
    url: url,
    headers: { "content-type": "application/json" },
    data: { ...defaultRegisterPost },
  };

  let resp = await localInstance.request(api);

  return resp.data;
};

export const getAllItems = async () => {
  const localInstance = duplicateInstance(moduleInstance);
  let url = `${import.meta.env.VITE_OAUTH2_AND_JWT_API}items`;

  const api = {
    method: "get",
    url: url,
  };

  localInstance.interceptors.request.use(requestAuthInterceptorBearerAuthLogin);
  localInstance.interceptors.response.use(
    responseAuthInterceptorBearerAuthLogin,
  );

  let resp = await localInstance.request(api);

  return resp.data;
};

export const createItem = async (defaultItemsPost) => {
  const localInstance = duplicateInstance(moduleInstance);
  let url = `${import.meta.env.VITE_OAUTH2_AND_JWT_API}items`;

  const api = {
    method: "post",
    url: url,
    headers: { "content-type": "application/json" },
    data: { ...defaultItemsPost },
  };

  localInstance.interceptors.request.use(requestAuthInterceptorBearerAuthLogin);
  localInstance.interceptors.response.use(
    responseAuthInterceptorBearerAuthLogin,
  );

  let resp = await localInstance.request(api);

  return resp.data;
};

export const getItemById = async (id) => {
  const localInstance = duplicateInstance(moduleInstance);
  let url = `${import.meta.env.VITE_OAUTH2_AND_JWT_API}items/${id}`;

  const api = {
    method: "get",
    url: url,
  };

  localInstance.interceptors.request.use(requestAuthInterceptorBearerAuthLogin);
  localInstance.interceptors.response.use(
    responseAuthInterceptorBearerAuthLogin,
  );

  let resp = await localInstance.request(api);

  return resp.data;
};

export const updateItem = async (defaultItemsPost, id) => {
  const localInstance = duplicateInstance(moduleInstance);
  let url = `${import.meta.env.VITE_OAUTH2_AND_JWT_API}items/${id}`;

  const api = {
    method: "put",
    url: url,
    headers: { "content-type": "application/json" },
    data: { ...defaultItemsPost },
  };

  localInstance.interceptors.request.use(requestAuthInterceptorBearerAuthLogin);
  localInstance.interceptors.response.use(
    responseAuthInterceptorBearerAuthLogin,
  );

  let resp = await localInstance.request(api);

  return resp.data;
};

export const deleteItem = async (id) => {
  const localInstance = duplicateInstance(moduleInstance);
  let url = `${import.meta.env.VITE_OAUTH2_AND_JWT_API}items/${id}`;

  const api = {
    method: "delete",
    url: url,
  };

  localInstance.interceptors.request.use(requestAuthInterceptorBearerAuthLogin);
  localInstance.interceptors.response.use(
    responseAuthInterceptorBearerAuthLogin,
  );

  let resp = await localInstance.request(api);

  return resp.data;
};
