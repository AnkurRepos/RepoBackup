
const entities = {}
const entityDetails = {
  "1d0851d3_7cdb_4aa1_8cf0_2e3bfe55c0b0": {
    "exportedAs": "Login110",
    "from": "/src/components/Login110.jsx",
    "default": true
  },
  "263696eb_9012_4fc9_8ab6_a3e7bb0b2f2d": {
    "exportedAs": "clearAuthSessionOAuth2AndJWTAPI",
    "from": "/src/services/OAuth2 and JWT API/authApis.jsx",
    "default": false
  },
  "38904244_0182_46cd_ba46_1ead069c491a": {
    "exportedAs": "createItem",
    "from": "/src/services/OAuth2 and JWT API/default.jsx",
    "default": false
  },
  "3e21abf3_6dba_445d_8ae7_a9a48e5f3fb4": {
    "exportedAs": "Login150",
    "from": "/src/components/Login150.jsx",
    "default": true
  },
  "4a63b26e_4b77_47b1_87a2_419cc3b5796e": {
    "exportedAs": "App",
    "from": "/src/App.jsx",
    "default": true
  },
  "4d894562_2a45_421f_990e_5be2faf13cf5": {
    "exportedAs": "Main",
    "from": "/src/components/Main.jsx",
    "default": true
  },
  "51051afa_8b33_466f_b225_21b1dda0ef20": {
    "exportedAs": "registerUser",
    "from": "/src/services/OAuth2 and JWT API/default.jsx",
    "default": false
  },
  "59681942_8a85_437e_95c1_e5d77adc7148": {
    "exportedAs": "Login500",
    "from": "/src/components/Login500.jsx",
    "default": true
  },
  "5ed938e3_bfe0_4e29_91b3_deeb295a845d": {
    "exportedAs": "Login250",
    "from": "/src/components/Login250.jsx",
    "default": true
  },
  "6f86a56d_6c42_4c9b_9034_b3b1dae465f6": {
    "exportedAs": "Login200",
    "from": "/src/components/Login200.jsx",
    "default": true
  },
  "712f96c4_63f1_46dd_ae85_4f726349b91c": {
    "exportedAs": "updateItem",
    "from": "/src/services/OAuth2 and JWT API/default.jsx",
    "default": false
  },
  "8134aa62_a577_456a_8699_336a8dc5c50c": {
    "exportedAs": "Layout",
    "from": "/src/components/Layout.jsx",
    "default": true
  },
  "8629887c_a468_45bc_b8f6_8918b0cda5c0": {
    "exportedAs": "loginUser",
    "from": "/src/services/OAuth2 and JWT API/default.jsx",
    "default": false
  },
  "94ca8b6a_e69b_4e8e_950a_e58ef6b7d0f7": {
    "exportedAs": "Login12",
    "from": "/src/components/Login12.jsx",
    "default": true
  },
  "9773fb73_dad8_41a5_a05c_b55029831e49": {
    "exportedAs": "googleAuthLogin",
    "from": "/src/services/OAuth2 and JWT API/authApis.jsx",
    "default": false
  },
  "9c4c3fba_f544_414e_bd2b_9214994508cf": {
    "exportedAs": "Login400",
    "from": "/src/components/Login400.jsx",
    "default": true
  },
  "PROJECT_ROUTER": {
    "exportedAs": "router",
    "from": "/src/Routing.jsx",
    "default": true
  },
  "bb8eb346_250c_4a2f_8392_295a2f35e203": {
    "exportedAs": "Login600",
    "from": "/src/components/Login600.jsx",
    "default": true
  },
  "bbc1c2f5_a80a_4dbe_ac0d_6c71a1db7d92": {
    "exportedAs": "bearerAuthLogin",
    "from": "/src/services/OAuth2 and JWT API/authApis.jsx",
    "default": false
  },
  "bf631bdb_ac05_4797_b0b5_432c7824ee97": {
    "exportedAs": "getItemById",
    "from": "/src/services/OAuth2 and JWT API/default.jsx",
    "default": false
  },
  "d42bea6b_2a66_4c4f_b5cd_4cac3267ba22": {
    "exportedAs": "Login1234",
    "from": "/src/components/Login1234.jsx",
    "default": true
  },
  "dab28c66_8bb8_4209_a75f_a0e51f465377": {
    "exportedAs": "Login300",
    "from": "/src/components/Login300.jsx",
    "default": true
  },
  "e130f7c2_b95a_4114_82b2_dee4b99209cd": {
    "exportedAs": "deleteItem",
    "from": "/src/services/OAuth2 and JWT API/default.jsx",
    "default": false
  },
  "e9238469_41e5_4fcb_abc4_7937ef229a79": {
    "exportedAs": "Login350",
    "from": "/src/components/Login350.jsx",
    "default": true
  },
  "ec727e6a_427f_49d6_bef1_8176d428e075": {
    "exportedAs": "exchangeAuthCodeForToken",
    "from": "/src/services/OAuth2 and JWT API/default.jsx",
    "default": false
  },
  "ed18966f_a437_4aca_bfa0_d5fd24534f51": {
    "exportedAs": "Login120",
    "from": "/src/components/Login120.jsx",
    "default": true
  },
  "f08ee920_6614_4d5b_b917_b588f7c60367": {
    "exportedAs": "Loginnn2",
    "from": "/src/components/Loginnn2.jsx",
    "default": true
  },
  "ffa17506_b584_4594_9714_c331dd48d808": {
    "exportedAs": "getAllItems",
    "from": "/src/services/OAuth2 and JWT API/default.jsx",
    "default": false
  }
}



export async function loadEntity(id) {
  const { from, default: isDefault } = entityDetails[id];
  if (!entities[id]) {
    try {
      const module = await import(from);
      const entity = isDefault
        ? module.default
        : module[entityDetails[id]["exportedAs"]];
      entities[id] = entity;
    } catch (error) {
      console.error(`Failed to load ${from}:`, error);
    }
  }
  return entities[id];
}

