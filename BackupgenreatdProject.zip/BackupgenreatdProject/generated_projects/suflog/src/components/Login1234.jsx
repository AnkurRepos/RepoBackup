import { useState } from "react";
import { bearerAuthLogin } from "/src/services/OAuth2 and JWT API/authApis.jsx";
import { googleAuthLogin } from "/src/services/OAuth2 and JWT API/authApis.jsx";
const Login1234 = () => {
  const [username, setUsername] = useState();
  const [password, setPassword] = useState();
  const handlebearerAuthLogin = async () => {
    try {
      await bearerAuthLogin(undefined);
    } catch (err) {
    } finally {
    }
  };
  const handlegoogleAuthLogin = async () => {
    try {
      await googleAuthLogin(undefined);
    } catch (err) {
    } finally {
    }
  };
  const handleUsernameChange = (event) => {
    setUsername(event.target.value);
  };
  const handlePasswordChange = (event) => {
    setPassword(event.target.value);
  };
  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
      }}
    >
      <form
        style={{
          background: "#fff",
          padding: "20px",
          borderRadius: "8px",
          boxShadow: "0 0 10px rgba(0,0,0,0.1)",
          width: "320px",
          textAlign: "center",
          margin: "0 auto",
        }}
        onSubmit={(e) => {
          e.preventDefault();
          handlebearerAuthLogin();
        }}
      >
        <label
          style={{ display: "block", fontSize: "20px", marginBottom: "5px" }}
        >
          Register
        </label>
        <input
          style={{
            width: "100%",
            padding: "7px",
            border: "1px solid #ccc",
            borderRadius: "5px",
            fontSize: "14px",
            marginBottom: "10px",
          }}
          onChange={handleUsernameChange}
          value={username}
          type={"text"}
          placeholder={"username"}
        />
        <input
          style={{
            width: "100%",
            padding: "7px",
            border: "1px solid #ccc",
            borderRadius: "5px",
            fontSize: "14px",
            marginBottom: "10px",
          }}
          onChange={handlePasswordChange}
          value={password}
          type={"text"}
          placeholder={"password"}
        />
        <button
          style={{
            width: "100%",
            padding: "7px",
            marginTop: "5px",
            background: "#007bff",
            color: "#fff",
            border: "none",
            borderRadius: "5px",
            fontSize: "16px",
            cursor: "pointer",
          }}
        >
          Submit
        </button>
      </form>
      <button
        style={{
          width: "100%",
          padding: "7px",
          marginTop: "5px",
          background: "#007bff",
          color: "#fff",
          border: "none",
          borderRadius: "5px",
          fontSize: "16px",
          cursor: "pointer",
        }}
      >
        Submit
      </button>
    </div>
  );
};
export default Login1234;
