import { useState } from "react";
import { bearerAuthLogin } from "/src/services/OAuth2 and JWT API/authApis.jsx";
import { googleAuthLogin } from "/src/services/OAuth2 and JWT API/authApis.jsx";
const Login120 = () => {
  const [username, setUsername] = useState();
  const [password, setPassword] = useState();
  const handlebearerAuthLogin = async () => {
    try {
      console.log("hi");
      await bearerAuthLogin({ username: username, password: password });
    } catch (err) {
    } finally {
    }
  };
  const handlegoogleAuthLogin = async () => {
    try {
      await googleAuthLogin(undefined);
    } catch (err) {
    } finally {
    }
  };
  const handleUsernameChange = (event) => {
    setUsername(event.target.value);
  };
  const handlePasswordChange = (event) => {
    setPassword(event.target.value);
  };
  return (
    <div
      style={{
        minHeight: "100vh",
        // display: "flex",
        alignItems: "center",
      }}
    >
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handlebearerAuthLogin();
        }}
        style={{
          background: "#fff",
          padding: "20px",
          borderRadius: "8px",
          boxShadow: "0 0 10px rgba(0,0,0,0.1)",
          width: "320px",
          textAlign: "center",
          margin: "0 auto",
        }}
      >
        <label
          style={{ display: "block", fontSize: "20px", marginBottom: "5px" }}
        >
          Login
        </label>
        <input
          onChange={handleUsernameChange}
          placeholder={"username"}
          style={{
            width: "100%",
            padding: "7px",
            border: "1px solid #ccc",
            borderRadius: "5px",
            fontSize: "14px",
            marginBottom: "10px",
          }}
          type={"text"}
          value={username}
        />
        <input
          onChange={handlePasswordChange}
          placeholder={"password"}
          style={{
            width: "100%",
            padding: "7px",
            border: "1px solid #ccc",
            borderRadius: "5px",
            fontSize: "14px",
            marginBottom: "10px",
          }}
          type={"text"}
          value={password}
        />
        <button
          style={{
            width: "100%",
            padding: "7px",
            marginTop: "5px",
            background: "#007bff",
            color: "#fff",
            border: "none",
            borderRadius: "5px",
            fontSize: "16px",
            cursor: "pointer",
          }}
        >
          Submit
        </button>
      </form>
      <div
        style={{
          display: "flex",
          alignItems: "center",
        }}
      >
        <button
          onClick={handlegoogleAuthLogin}
          style={{
            padding: "5px",
            marginTop: "5px",
            background: "#007bff",
            color: "#fff",
            border: "none",
            borderRadius: "5px",
            fontSize: "10px",
            cursor: "pointer",
          }}
        >
          googleAuthLogin
        </button>
      </div>
    </div>
  );
};
export default Login120;
