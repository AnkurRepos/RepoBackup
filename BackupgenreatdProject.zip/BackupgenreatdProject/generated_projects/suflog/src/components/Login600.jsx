import { useState } from "react";
import { bearerAuthLogin } from "/src/services/OAuth2 and JWT API/authApis.jsx";
import { googleAuthLogin } from "/src/services/OAuth2 and JWT API/authApis.jsx";
const Login600 = () => {
  const [username, setUsername] = useState();
  const [password, setPassword] = useState();
  const handlebearerAuthLogin = async () => {
    try {
      await bearerAuthLogin({ username: username, password: password });
    } catch (err) {
    } finally {
    }
  };
  const handlegoogleAuthLogin = async () => {
    try {
      await googleAuthLogin();
    } catch (err) {
    } finally {
    }
  };
  const handleUsernameChange = (event) => {
    setUsername(event.target.value);
  };
  const handlePasswordChange = (event) => {
    setPassword(event.target.value);
  };
  return (
    <div
      style={{
        // minHeight: "100vh",
        // display: "flex",
        alignItems: "center",
        background: "#fff",
        padding: "20px",
        borderRadius: "8px",
        boxShadow: "0 0 10px rgba(0,0,0,0.2)",
        width: "35%",
        textAlign: "center",
        margin: "0 auto",
      }}
    >
      <form
        style={{
          background: "#fff",
        }}
        onSubmit={(e) => {
          e.preventDefault();
          handlebearerAuthLogin();
        }}
      >
        <label
          style={{ display: "block", fontSize: "20px", marginBottom: "8px" }}
        >
          Login
        </label>
        <input
          style={{
            width: "100%",
            padding: "7px",
            border: "1px solid #ccc",
            borderRadius: "5px",
            fontSize: "14px",
            marginBottom: "18px",
          }}
          onChange={handleUsernameChange}
          value={username}
          type={"text"}
          placeholder={"username"}
        />
        <input
          style={{
            width: "100%",
            padding: "7px",
            border: "1px solid #ccc",
            borderRadius: "5px",
            fontSize: "14px",
            marginBottom: "18px",
          }}
          onChange={handlePasswordChange}
          value={password}
          type={"text"}
          placeholder={"password"}
        />
        <button
          style={{
            width: "100%",
            padding: "7px",
            marginTop: "5px",
            background: "#347c9d",
            color: "#fff",
            border: "none",
            borderRadius: "2px",
            fontSize: "14px",
            cursor: "pointer",
          }}
        >
          Login
        </button>
      </form>
      <div
        style={{
          display: "flex",
          alignItems: "center",
          marginTop: "10px",
        }}
      >
        <button
          style={{
            padding: "7px",
            width: "100%",
            marginTop: "10px",
            background: "#dfebe7",
            color: "#0a0a0a",
            border: "none",
            borderRadius: "2px",
            fontSize: "12px",
            cursor: "pointer",
          }}
          onClick={handlegoogleAuthLogin}
        >
          googleAuthLogin
        </button>
      </div>
    </div>
  );
};
export default Login600;
