const Main = ({ prop1 }) => {
  return <div>Hello worldDD</div>;
};
export default Main;
