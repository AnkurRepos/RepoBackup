
const entities = {}
const entityDetails = {
  "00eedcf1_5d7b_4574_86b4_be345534b16d": {
    "exportedAs": "Main",
    "from": "/src/components/Main.jsx",
    "default": true
  },
  "05c06c2b_2759_4a67_a2e0_aa4db1c3624e": {
    "exportedAs": "getProfiles",
    "from": "/src/services/Big Schema Example API/default.jsx",
    "default": false
  },
  "3e01c238_9e1a_4bca_8533_944ed1e4c694": {
    "exportedAs": "Main",
    "from": "/src/components/Main.jsx",
    "default": true
  },
  "433aa9ec_f825_4ce1_8a7f_94f6b237d688": {
    "exportedAs": "App",
    "from": "/src/App.jsx",
    "default": true
  },
  "690cad50_0bb5_43e0_832e_5f5c41d7d617": {
    "exportedAs": "Main",
    "from": "/src/components/Main.jsx",
    "default": true
  },
  "810bd717_b77a_4c81_9fec_7a10a0ec07f1": {
    "exportedAs": "Main",
    "from": "/src/components/Main.jsx",
    "default": true
  },
  "PROJECT_ROUTER": {
    "exportedAs": "router",
    "from": "/src/Routing.jsx",
    "default": true
  },
  "STYLES_MASTER": {
    "exportedAs": "stylesMaster",
    "from": "/src/stylesMaster.jsx",
    "default": false
  },
  "THEME_CSS": {
    "exportedAs": "ThemeContext",
    "from": "/src/styles/ThemeContext.css",
    "default": false
  },
  "THEME_HOOK": {
    "exportedAs": "useThemeContext",
    "from": "/src/context/ThemeContext.jsx",
    "default": false
  },
  "THEME_PROVIDER": {
    "exportedAs": "ThemeProvider",
    "from": "/src/context/ThemeContext.jsx",
    "default": false
  },
  "a5c44a7d_3fcc_44d4_a033_dfa04df865c0": {
    "exportedAs": "Main",
    "from": "/src/components/Main.jsx",
    "default": true
  },
  "f1240f0c_b987_4f5a_9987_e6370045c032": {
    "exportedAs": "Main",
    "from": "/src/components/Main.jsx",
    "default": true
  },
  "fc9bdc52_db7f_48ce_ab36_ab49ccee1114": {
    "exportedAs": "Main",
    "from": "/src/components/Main.jsx",
    "default": true
  },
  "bfd825a6_a961_40db_a2d1_9a0d0c1fb5d0": {
    "exportedAs": "Main",
    "from": "/src/components/Main.jsx",
    "default": true
  }
}



export async function loadEntity(id) {
  const { from, default: isDefault } = entityDetails[id];
  if (!entities[id]) {
    try {
      const module = await import(from);
      const entity = isDefault
        ? module.default
        : module[entityDetails[id]["exportedAs"]];
      entities[id] = entity;
    } catch (error) {
      console.error(`Failed to load ${from}:`, error);
    }
  }
  return entities[id];
}

